console.log("working");
var cookiepolicy = document.querySelector(".footer-header")

function loading(){
    alert("Loading weather report...")
}

function remove(){
    cookiepolicy.remove();
}