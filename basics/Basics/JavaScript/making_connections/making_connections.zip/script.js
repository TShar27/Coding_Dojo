console.log("Loading...");

 var countElement = document.querySelector("#name");

 console.log(countElement);

function changeName() {
    countElement.innerText = "Timmy Shar";
    console.log();
}

function remove(Element){
    Element.remove();
}

var count = 2;
var countElement = document.querySelector("connections");

function subtract1(){
   count--;
   console.log(count) 
}
